
from twisted.scripts.mktap import _tapHelper
 	
Punjab = _tapHelper(
 	        "Punjab",
                "punjab.tap",
 	        "A HTTP XMPP client interface",
                "punjab")
